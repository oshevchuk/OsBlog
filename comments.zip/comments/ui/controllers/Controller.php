<?php
namespace ui\controllers;

use system\core\View;

abstract class Controller
{
    protected $view;

    public function __construct()
    {
        $this->view = new View('layouts/main');
        $this->view->addData('pageTitle', 'Undefined');
    }

    public function error($code)
    {
        $this->view->load("errors/$code", ['pageTitle' => 'Error']);
    }
}