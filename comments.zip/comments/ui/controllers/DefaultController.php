<?php
namespace ui\controllers;

use system\core\Db;

class DefaultController extends Controller
{
    private $db;
    public function __construct()
    {
        $this->db = new Db();
        parent::__construct();
    }

    public function index()
    {
        if(isset($_POST['text'])&&isset($_SESSION['username'])){
            $this->db->setComment($_POST['text'], $_SESSION['username']);
        }

        $stmt = $this->db->getComments();

        if (isset($_POST["loginname"]) && !isset($_GET["go"])) {
            $_SESSION['username'] = $_POST['loginname'];
        } else if (isset($_GET["go"])) {
            unset($_SESSION['username']);
            header("location: index");
        }

        $this->view->load('index', [
            'stmt' => $stmt,
            'global_post'=>'blog-4',
            'pageTitle' => "Comments"
        ]);

    }

    public function deleteComent($id)
    {
        echo $this->db->deleteComment($id);
    }

    public function updateComment($id)
    {
        if (isset($_POST["new_comment_post"])) {
            echo $this->db->updateComment($id, $_POST["new_comment_post"]);
        }
    }

    public function likeComment($id){
        echo $this->db->like($id);
    }
}