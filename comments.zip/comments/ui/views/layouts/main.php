<html>
<head>
    <title><?= $pageTitle ?></title>
    <base href="http://localhost/comments/"/>
    <link rel="stylesheet" href="ui/web/css/style.css">
    <script src="ui/web/scripts/script.js"></script>

</head>
<body>
<ul class="top-menu">

</ul>
<div class="content">

<?= $pageContent ?>

</div>
</body>
</html>