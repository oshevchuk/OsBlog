<?php
if (isset($_SESSION['username'])) {
    ?>
    <div class="hello_user">
        Hello <span> <?= $_SESSION['username']; ?></span>
        <a href='index.php?go=exit'>(logout)</a>
    </div>
    <?php
} else {
    ?>
    <div class="loginPage">
        <h3>
            Hello <b>Guest!</b>
        </h3>
        <form method="post">
            Please Enter you name: <input type="text" name="loginname" class="loginname">
            <input type="submit" value="Enter" class="real_update_button">
        </form>
    </div>

<?php } ?>
<!-- display the post for comment -->
<div class="post">
    <h1>This is the post name</h1>
    <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.</span>
    <img src="ui/web/img/<?= $global_post ?>.jpg">
</div>


<!-- display the list of comments -->
<div class="commets">
    <?php
    foreach ($stmt as $item) {
        extract($item);
        ?>
        <div class="comment" id="post<?= $id ?>" xmlns="http://www.w3.org/1999/html">
            <div class="avatar">
                <img src="ui/web/img/<?= (ord($author[0]) % 2 == 0) ? "man" : "girl" ?>.png" width="100px"
                     height="100px">
            </div>
            <div class="message">
                <h2 class="username">
                    <?= $author; ?>
                    <?php if (isset($_SESSION['username']) && $_SESSION['username'] == $author) { ?>
                        <button onclick="deleteComent(<?= $id ?>)" class="deleteButton"></button>
                    <?php } ?>
                </h2>
                <p class="coment_post">
                    <span id="old<?= $id ?>"> <?= $post; ?></span>

                    <?php if (isset($_SESSION['username']) && $_SESSION['username'] == $author) { ?>

                        <input type="textarea" name="edit" value="<?= $post ?>" id="text<?= $id ?>"
                               class="post_edit_text" style="display: none">
                        <input type="text" value="<?= $id ?>" name="post" style="display: none">
                        <button onclick="updateComment(<?= $id ?>)" id="up<?= $id ?>" style="display: none"
                                class="real_update_button">Update
                        </button>
                        <button class="edit_button" onclick="show_edit(<?= $id ?>)"></button>
                    <?php } ?>

                </p>
                <i>
                    <?= $time; ?>

                    <span class="rating">
                       <span id="rating<?= $id ?>"><?= $rating ?></span> likes
                    </span>
                    <?php if (isset($_SESSION['username']) && $_SESSION['username'] != $author) { ?>
                        <a class="likelink" onclick="like_coment(<?= $id ?>);return false" >like it </a>
                    <?php } ?>
                </i>
                <span class="postId" id="r"></span>


            </div>
            <div class="clear"></div>
        </div>
    <?php } ?>

    <!-- Add new Post Field is active when user is authorized -->
    <?php if (isset($_SESSION['username'])) { ?>

        <form action="index" method="post">
            <input type="text" name="text" class="add_new_post_text">
            <input type="submit" value="Add Post" class="add_new_post_button">

        </form>

    <?php } ?>

</div>