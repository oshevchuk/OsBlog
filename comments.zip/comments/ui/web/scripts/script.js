/**
 * Created by megad on 10.11.2016.
 */



function getCOntent()
{
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'getComments.php', false);
    xhr.send();
    if (xhr.status != 200) { //error
        alert(xhr.status + ': ' + xhr.statusText);
    } else {
        document.getElementById("content").innerHTML = xhr.responseText;
    }
}


function deleteComent(id)
{
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'deleteComent/' + id, false);
    xhr.send();
    if (xhr.status != 200) {
        alert(xhr.status + ': ' + xhr.statusText);
    } else {
        if (xhr.responseText == "ok") {
            var el = document.getElementById("post" + id);
            el.parentNode.removeChild(el);
        }
    }

}

function updateComment(id)
{
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'updateComment/' + id, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("new_comment_post=" + document.getElementById("text" + id).value);
    var results = '';
    xhr.onreadystatechange = function () {
        if (xhr.readyState != 4) return;

        if (xhr.status == 200) {
            results = xhr.responseText;
            document.getElementById("up" + id).style.display = 'none';
            document.getElementById("text" + id).style.display = 'none';
            document.getElementById("old" + id).innerText=document.getElementById("text" + id).value;
            document.getElementById("old" + id).style.display = 'inline-block';
        }
        else {
            results = 'Error';
        }
    };
}

function show_edit(id)
{
    document.getElementById("up" + id).style.display = 'inline-block';
    document.getElementById("text" + id).style.display = 'inline-block';
    document.getElementById("old" + id).style.display = 'none';
}

function like_coment(id)
{

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'likeComment/' + id, false);
    xhr.send();
    if (xhr.status != 200) {
        alert(xhr.status + ': ' + xhr.statusText);
    } else {
        if (xhr.responseText == "ok") {
            document.getElementById("rating"+id).innerText=parseInt(document.getElementById("rating"+id).innerText)+1;
        }
    }
}

function refreshComment(){

}

//getCOntent();


