<?php
namespace system\core;

class View
{
    private $viewsDir = APP . '/views';
    private $layoutPath;
    private $data = [];

    public function __construct($layout)
    {
        $layoutPath = "$this->viewsDir/$layout.php";

        if(file_exists($layoutPath))
        {
            $this->layoutPath = $layoutPath;
        }
        else
        {
            throw new \Exception("Layout [$layoutPath] not found");
        }
    }

    public function addData($key, $value = null)
    {
        if(is_array($key))
        {
            $this->data = array_merge($this->data, $key);
        }
        else
        {
            $this->data[$key] = $value;
        }
        return $this;
    }

    public function load($title, array $data = array())
    {
        $this->addData($data);

        $filePath = "$this->viewsDir/$title.php";

        if(isset($this->layoutPath) && file_exists($filePath))
        {
            $this->data['pageContent'] = $this->getContantPage($filePath);
            extract($this->data);
            require $this->layoutPath;
        }
        else
        {
            throw new \Exception("View [$filePath] not found");
        }
    }

    private function getContantPage($pagePath)
    {
        ob_start();

        extract($this->data);
        require $pagePath;

        $data = ob_get_contents();
        ob_end_clean();

        return $data;
    }
}