<?php
namespace system\core;

use system\settings;
use PDO;

class Db
{
    private $dsn;
    private $opt;
    private $pdo;

    public function __construct()
    {
        $settings = require 'settings/dbConfig.php';

        $dsn = $settings['dsn'];

        $opt=array(
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
        );
        $pdo=new PDO($dsn, $settings['login'], $settings['password'], $opt);

        $this->dsn=$dsn;
        $this->opt=$opt;
        $this->pdo=$pdo;
    }

    public function getComments($user=null)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM comment');
        $stmt->execute(array());
        return $stmt;
    }

    public function setComment($text, $author)
    {
        $this->pdo->query("INSERT INTO `comment` (`id`, `author`, `post`, `time`) VALUES (NULL, '".$author."', '".$text."', CURRENT_TIMESTAMP);");
    }

    public function deleteComment($id)
    {
        $this->pdo->query("DELETE FROM `comment` WHERE `comment`.`id` = ".$id);
        return "ok";
    }

    public function updateComment($id, $text)
    {
        $this->pdo->query("UPDATE `comment` SET `post` = '".$text."', `time` = CURRENT_TIMESTAMP WHERE `comment`.`id` = ".$id);
        return "ok";
    }

    public function like($id)
    {
        $this->pdo->query("UPDATE `comment` SET `rating` = `rating` + 1 WHERE `comment`.`id` = ".$id);
        return "ok";
    }
}