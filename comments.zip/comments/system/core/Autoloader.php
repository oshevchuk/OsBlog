<?php
namespace system\core;

class Autoloader
{
    public static function autoload($path)
    {
        $path = "$path.php";

        if(file_exists($path))
        {
            require $path;
        }
    }
}

\spl_autoload_register('system\core\Autoloader::autoload');