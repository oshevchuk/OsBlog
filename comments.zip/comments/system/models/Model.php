<?php
namespace system\models;

abstract class Model
{
    protected $db;
    protected $table;

    public function __construct()
    {
        $this->db = new Db();
    }

    public function selectAll()
    {
        $query = "select * from `$this->table`";
        return $this->db->query($query);
    }

    public function selectById($id)
    {
        $query = "select * from `{$this->getTable()}` where id = $id";
        return $this->db->query($query);
    }

    public function update(arrya $data)
    {
        $query = "update `{$this->getTable()}`";
        $this->db->query($query);
    }
}