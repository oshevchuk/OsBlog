<?php
session_start();
require_once 'system/core/Autoloader.php';

define('APP', 'ui');

new \system\core\Init;