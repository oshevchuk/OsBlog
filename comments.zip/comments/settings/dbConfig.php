<?php
return [
    'dsn' => 'mysql:host=localhost;dbname=portal',
    'login' => 'root',
    'password' => '',
];